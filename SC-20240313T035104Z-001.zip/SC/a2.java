public class a2  {
    public static void main (String args[]){
        try{
            System.out.println("Seu nome é:" + args[1]);
        }
        catch(IndexOutOfBoundsException e){
            System.out.println("Digite 2 argumentos");
        }
    }
}
