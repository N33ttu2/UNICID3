public class a4 {
    public static void main(String args []){
        boolean x = false;
        int a;
        if(x){
            a = x ? 3: 2; //op ternario 
        }
        else{
            a = x ? 3: 4; //op ternario
        }
        System.out.println(a);
    }
}
