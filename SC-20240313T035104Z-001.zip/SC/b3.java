import java.util.Scanner;
/*
 * 3) Crie um programa 
 * que receba a largura e o comprimento de um lote de
 *  terra emostre a área total existente.
 */
public class b3 {
public static void main(String[] args) {
    Scanner bd = new Scanner(System.in);
    System.out.println("Digite a largura:" );
    double larg = bd.nextDouble();
    System.out.println("Digite o comprimeto: ");
    double compri = bd.nextDouble();

    double area = (larg * compri);
    System.out.println("A área é: " + area);
    bd.close();


}    
    
    
}
