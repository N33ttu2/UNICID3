public class a5 {
    public static void main(String[] args) {
        int a = 10;
        int b = 6;
        int c = 3;
        int d = a + b / c;
        System.out.println("d=" +d ); 

    }
}
