
//1) Crie um programa que recebe três nomes
// quaisquer por meio da linha deexecução do programa, e os imprima na tela da seguinte maneira: o primeiro e oúltimo nome serão impressos na primeira linha um após o outro, o outro nome(segundo) será impresso na segunda linha.

public class b1 {
    public static void main(String args[]) {
       if(args.length < 3 ){
        System.out.println("Por favor forneca 3 nomes: ");
        return;
    }

    String pnome = args [0];
    String snome = args [1];
    String tnome = args [2];

    System.out.println(pnome + tnome);

    System.out.println(snome);

    }
    
}
