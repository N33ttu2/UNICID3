public class a3 {
    public static void main(String [] args){
        try{
            System.out.println("A");
        }
        catch(Exception ex){
            System.out.println("B");
        }
        finally{
            System.out.println("C");
        }
        System.out.println("D");
    }
}
