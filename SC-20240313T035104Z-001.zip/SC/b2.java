/*2) Faça um programa que receba a quantidade e o valor de dois produtos, noseguinte formato: 
quantidade1 valor1 quantidade2 valor2. O programa devecalcul
ar esses valores 
seguindo a fórmula total = (quantidade1 x valor1) +(quantidade2 x valor2). O valor total deve ser apresentado no final da execução */

public class b2 {
    public static void main(String[] args) {
        if (args.length < 4){
            System.err.println("digite a quantidade e o valor ");
            return;
        }
        int quantidade1 = Integer.parseInt(args[0]);
        double valor1 = Double.parseDouble(args[1]);
        int quantidade2 = Integer.parseInt(args[2]);
        double valor2 = Double.parseDouble(args[3]);
        double total = (quantidade1 * valor1) + (quantidade2 + valor2);

        System.out.println("O valor é " + total);
    }
    
}
