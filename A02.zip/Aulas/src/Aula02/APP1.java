package Aula02;

public class APP1 {

	public static void main(String[] args) {
		int soma = 0;
		for(int i = 1; i <= 100; i++) {
			soma = soma + i;
		}
		System.out.println("Soma " + soma);

	}

}
