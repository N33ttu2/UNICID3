package Aula02;

import java.util.Scanner;

public class App3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("digite o valor: ");
		int v1 = sc.nextInt();
		System.out.println("digite o valor: ");
		int v2 = sc.nextInt();
		
		int media = (v1 + v2) / 2;
		System.out.println("media salarial: " + media);
		
	

	}

}
