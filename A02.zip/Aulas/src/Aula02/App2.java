package Aula02;
import java.util.Scanner;

public class App2 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite seu nome: ");
		String nome = sc.nextLine();
		System.out.println("Seu nome é: " + nome);
		
		System.out.println("Digite seu idade: ");
		int idade = sc.nextInt();
		System.out.println("Seu nome é: " + idade);
		
		System.out.println("Digite seu Salário: ");
		double salario = sc.nextDouble();
		System.out.println("Seu Salário é: " + salario);
		
		
		
	}

}
