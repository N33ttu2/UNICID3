package Aula02;

import java.util.Iterator;

public class App4 {

	public static void main(String[] args) {
		System.out.println(Math.abs(-10)); //numero absoluto ou positivo
		System.out.println(Math.sqrt(25)); //raiz quadrada
		System.out.println(Math.pow(5, 7)); //exponencial ou potência
		System.out.println(Math.random()); // randomizar numero
		
		for (int i = 1; i <= 100; i++) {
			System.out.println((int)(Math.random()*10));//conversão explicita
			
		}
			
		}

	}


